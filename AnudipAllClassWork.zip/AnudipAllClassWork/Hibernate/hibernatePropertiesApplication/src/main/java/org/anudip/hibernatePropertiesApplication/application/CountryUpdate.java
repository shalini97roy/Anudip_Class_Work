package org.anudip.hibernatePropertiesApplication.application;

import java.util.Scanner;

import org.anudip.hibernatePropertiesApplication.bean.Country;
import org.anudip.hibernatePropertiesApplication.da0.DatabaseHandler;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class CountryUpdate {

	public static void main(String[] args)  throws Exception{
	        // Create Hibernate configuration and session factory
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
   	    Session session=dbHandler.createSession();
	        SessionFactory factory = null;
			try (Session session1 = factory.openSession()) {
	            // Create a Scanner for user input
	            Scanner scanner = new Scanner(System.in);
	            System.out.print("Enter the country code: ");
	            String countryCode = scanner.nextLine();

	            // Create a Criteria instance for querying
	            Criteria criteria = session1.createCriteria(Country.class);
	            criteria.add(Restrictions.eq("countryCode", countryCode));
	            Country country = (Country) criteria.uniqueResult();

	            if (country != null) {
	                // Display country details
	                System.out.println("Country Code: " + countryCode);
	                System.out.println("Country Name: " + country.getCountryName());
	                System.out.println("Capital: " + country.getCapital());
	                System.out.println("GDP: " + country.getGdp());
	            } else {
	                System.out.println("Country not found with code: " + countryCode);
	            }

	            // Close the scanner
	            scanner.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            // Close the session and factory
	            factory.close();
	        }    }
}
