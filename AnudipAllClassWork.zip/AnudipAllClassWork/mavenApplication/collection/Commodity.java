package org.anudip.mavenApplication.collection;
public class Commodity {
	private Integer productId;
	private String productName;
	private Double productPrice;
	public Commodity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Commodity(Integer productId, String productName, Double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		String output=String.format("%-5s %-15s %-10s",productId,productName,productPrice);
		return  output;
	}
	@Override
	public int hashCode() {
		return this.productId;
	}
	@Override
	public boolean equals(Object obj) {
		Commodity other = (Commodity) obj;
		if (this.hashCode()==other.hashCode())
			return true;
		else
			return false;
	}	
	}
