package org.anudip.mavenApplication.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class ArrayListDemo1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of product to store: ");
		int no=Integer.parseInt(sc.nextLine());	
		ArrayList <Product>productList = new ArrayList<Product>();
		for(int i=0;i<no;i++)   {
			System.out.println("Enter product details in comma(,) separated String");
			String stg=sc.nextLine();
			String [] arr =stg.split(",");
			int id=Integer.parseInt(arr[0]);
			double price=Double.parseDouble(arr[2]);
			Product product = new Product(id,arr[1],price);
			//productList.add(product);
			productList.add(product);
		}//end of loop
		System.out.println("Display in order of entry:----");
		productList.forEach(prod->System.out.println(prod));
		System.out.println("Display ascending order of Product Id:----");
		Collections.sort(productList);
		productList.forEach(prod->System.out.println(prod));
		System.out.println("Display descending order of Product Id:----");
		Collections.reverse(productList);
		productList.forEach(prod->System.out.println(prod));
	}
	}
			
			
			
		/*myList.add("Rose");
		myList.add("Lotus");
		myList.add("Lily");
		myList.add("Rose");
		myList.add("Marigold");
		myList.add("Jasmine");
		myList.add("cosmos");
		myList.add("Jasmine");
		myList.add("Delhia");
		myList.add("Zenia");
		myList.add("Tulip");
		System.out.println("Display in the order of entry with forEach loop");
		for(String str:myList) {
			System.out.println(str);
		}
		ListIterator<String> iterator = myList.listIterator();

		System.out.println("Display in the order of entry from 1st to last with ListTterator :-");
		while (iterator.hasNext())  {
			String stg=iterator.next();
			System.out.println(stg);
			
		}
		System.out.println("Display in the order of entry from last to 1st with ListTterator :-");

		while (iterator.hasNext())  {
			String stg=iterator.previous();
			System.out.println(stg);
		System.out.println("Display in the order of entry with Lambda Expression");
		myList.forEach(str->System.out.println(str));
		System.out.println("Display in ascending order:-");
		Collections.sort(myList);
		myList.forEach(str->System.out.println(str));	
		System.out.println("Display in descending order:-");
		Collections.reverse(myList);
		myList.forEach(str->System.out.println(str));*/
