package org.anudip.mavenApplication.collection;
import java.util.ArrayList;
public class ArrayListDemo2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Product>productList = new ArrayList<Product>();
		/*myList.add("Rose");
		myList.add("Lotus");
		myList.add("Lily");
		myList.add("Rose");
		myList.add("Marigold");
		myList.add("Jasmine");
		myList.add("cosmos");
		myList.add("Jasmine");
		myList.add("Delhia");
		myList.add("Zenia");
		myList.add("Tulip");
		System.out.println("Display in the order of entry with forEach loop");
		for(String str:myList) {
			System.out.println(str);
		}
		System.out.println("Display in the order of entry with Lambda Expression");
		myList.forEach(str->System.out.println(str));
		System.out.println("Display in accending order->");
		Collections.sort(myList);
		myList.forEach(str->System.out.println(str));
		System.out.println("Display in descending order->");
		Collections.reverse(myList);
		myList.forEach(str->System.out.println(str));*/
	}
	}
