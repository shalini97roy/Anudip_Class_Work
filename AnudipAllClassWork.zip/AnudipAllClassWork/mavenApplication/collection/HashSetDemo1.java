package org.anudip.mavenApplication.collection;
import java.util.HashSet;
public class HashSetDemo1 {	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet <String>mySet = new HashSet<String>();
		mySet.add("Rose");
		mySet.add("Lotus");
		mySet.add("Lily");
		mySet.add("Rose");
		mySet.add("Marigold");
		mySet.add("Sunflower");
		mySet.add("Jasmine");
		mySet.add("Cosmos");
		mySet.add("Jasmine");
		mySet.add("Delhia");
		mySet.add("Zenia");
		mySet.add("Tulip");
		mySet.add("Sunflower");
		System.out.println("Display :-");
		mySet.forEach(str->System.out.println(str));
	}
}