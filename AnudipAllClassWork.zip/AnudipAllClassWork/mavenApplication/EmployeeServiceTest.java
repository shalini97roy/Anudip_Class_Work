package org.anudip.mavenApplication;

import static org.junit.jupiter.api.Assertions.*;

import org.anudip.mavenApplication.app.Employee;
import org.anudip.mavenApplication.app.EmployeeService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class EmployeeServiceTest {
	private static Employee employee;
	private static EmployeeService empService;
	
	@BeforeAll
	public static void init(EmployeeService empService)  {
		empService=new EmployeeService ();
		
	}

	@Test
	void testTaxCalculation1() {
		Employee employee=new Employee(505,"Hilda Hills",75000.00);
		String expected="90000.00";
		EmployeeService empService=new EmployeeService();
		String actual=empService.taxCalculation(employee);
		assertEquals(expected,actual);
	}
	
	@Test
	void testTaxCalculation2() {
		Employee employee=new Employee(505,"Hilda Hills",125000.00);
		String expected="375000.00";
		EmployeeService empService=new EmployeeService();
		String actual=empService.taxCalculation(employee);
		assertEquals(expected,actual);
	}

}
