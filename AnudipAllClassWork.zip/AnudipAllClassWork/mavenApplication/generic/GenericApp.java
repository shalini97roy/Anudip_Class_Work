package org.anudip.mavenApplication.generic;
public class GenericApp {
	public static void main(String[] args) {
		Integer i=5;
		Integer j=6;
		Double d1=3.75;
		Double d2=4.56;
		String str="ABC";
		String stg="XYZ";
		/*int m=3;
		int n=4;*/
		GenericDemo<Integer> gd1=new GenericDemo<>();
		gd1.swapData(i, j);
		GenericDemo<String> gd2=new GenericDemo<>();
		gd2.swapData(str, stg);
		GenericDemo<Double> gd3=new GenericDemo<>();
		gd3.swapData(d1, d2);
		Demo dm1=new Demo(10,11.25);
		Demo dm2= new Demo(20,22.50);
		GenericDemo<Demo>gd4=new GenericDemo<>  ();
		gd4.swapData(dm1, dm2);
		/*GenericDemo<int>gd5=new GenericDemo<>  ();
		gd4.swapData(dm1, dm2);*/
		
	}

}
