package org.anudip.mavenApplication.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
public class DataShow {
	public static void main(String[] args) throws Exception{
		ArrayList<Department> departmentList=new ArrayList<>();
		DatabaseHandler dbHandler=DatabaseHandler.gettDatabaseHandler();
		Connection connection=dbHandler.getConnection();
		String sqlStatement="Select * from department";
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery(sqlStatement);
		while (resultSet.next()) {
			int id=resultSet.getInt(1);
			String name=resultSet.getString(2);
			String location=resultSet.getString(3);
			Department department=new Department(id,name,location);
            departmentList.add(department);
		}//end of loop
		connection.close();
		departmentList.forEach(dept->System.out.println(dept));
	}
}
