package org.anudip.mavenApplication.single;

public class MultiMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MultiDemo md1=new MultiDemo();
		System.out.println("From md1:"+md1.getdata());
		md1.putdata(15);
		System.out.println("From md1:"+md1.getdata());
		MultiDemo md2=new MultiDemo();
		System.out.println("From md2:"+md2.getdata());
	}

}
