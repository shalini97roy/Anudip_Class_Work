/**
 * 
 */
/**
 * 
 */
module MySecondApplication {
}