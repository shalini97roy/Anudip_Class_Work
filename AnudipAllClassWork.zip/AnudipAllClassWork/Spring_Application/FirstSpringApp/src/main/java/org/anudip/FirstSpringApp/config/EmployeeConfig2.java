package org.anudip.FirstSpringApp.config;
//It is act as setter based Dependency Injection

import org.anudip.FirstSpringApp.bean.Address;
import org.anudip.FirstSpringApp.bean.Employee;
import org.springframework.context.annotation.Bean;

public class EmployeeConfig2 {

	@Bean
	public Address address()  {
		Address add=new Address();
		add.setStreet("25,Cannought Place");
		add.setCity("New Delhi");
		add.setPin(110025);
		return add;
	}
	
	@Bean
	public Employee employee()  {
		Employee ee=new Employee();
		ee.setEmployeeId(10009);
		ee.setEmployeeName("Louren Silver");
		ee.setEmployeeAddress(address());
		ee.setEmployeeSalary(56000.00);
		return ee;
	}
}
