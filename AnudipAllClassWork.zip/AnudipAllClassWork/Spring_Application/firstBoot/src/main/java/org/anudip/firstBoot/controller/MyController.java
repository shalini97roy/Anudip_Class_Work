package org.anudip.firstBoot.controller;

import org.anudip.firstBoot.service.PrimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class MyController {
	@Autowired
	PrimeService pService;

	@GetMapping("/index")
	public ModelAndView showIndexPage()  {
		ModelAndView mv=new ModelAndView("indexPage");
		return mv;
	}
	
	@GetMapping("/home")
	public ModelAndView showHomePage()  {
		return new ModelAndView("homePage");
	}
	@GetMapping("/abc")
	public ModelAndView showNextPage()  {
		return new ModelAndView("nextPage");
	}
	
	@GetMapping("/accept")
	public ModelAndView showAcceptPage()   {
		return new ModelAndView("acceptPage");

	}
	
	@PostMapping("/prime-check")
	public ModelAndView showPrimeResult(@RequestParam("mynum") int num) {
	boolean flag = pService.primeCheck(num);
	String msg="";
	if(flag) 
		msg=num+" is a prime number";
	else
			msg=num+" is not a prime number";
	ModelAndView mv = new ModelAndView("displayPage");
	mv.addObject("message",msg);
	return mv;
		}
		
	}

