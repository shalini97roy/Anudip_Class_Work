import java.util.Scanner;
public class SubstringDisplay {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        System.out.print("Enter the start position: ");
        int startPosition = scanner.nextInt();

        System.out.print("Enter the number of characters to display: ");
        int numChars = scanner.nextInt();

        String substring = getSubstring(inputString, startPosition, numChars);
        System.out.println("Substring: " + substring);

        scanner.close();
    }

    public static String getSubstring(String inputString, int startPosition, int numChars) {
        int endPosition = startPosition + numChars;
        return inputString.substring(startPosition, endPosition);
    }

}
