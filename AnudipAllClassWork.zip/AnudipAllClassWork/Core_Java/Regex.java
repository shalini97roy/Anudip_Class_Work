import java.util.Scanner;
import java.util.regex.*;
public class Regex {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter a name: ");
	        String name = scanner.nextLine();

	        // Define the regex pattern to match names with titles
	        Pattern pattern = Pattern.compile("^(Mr\\.|Mrs\\.|Ms\\.)");

	        // Check if the name matches the pattern
	        Matcher matcher = pattern.matcher(name);
	        if (matcher.find()) {
	            System.out.println("Name is properly formatted.");
	        } else {
	            System.out.println("Name is not properly formatted.");
	        }
	    }
	}

