import java.util.Scanner;
import java.util.regex.*;
public class GmailCheckerApplication {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter an email address: ");
	        String email = scanner.nextLine();

	        // Define the regex pattern to match Gmail addresses
	        Pattern pattern = Pattern.compile("^\\w+@gmail\\.com");

	        // Check if the email matches the pattern
	        Matcher matcher = pattern.matcher(email);
	        if (matcher.find()) {
	            System.out.println("Email is a Gmail address.");
	        } else {
	            System.out.println("Email is not a Gmail address.");
	        }
	    }
	}