package org.anudip.application;
public class Student {
	// member data
	private Integer rollNumber;
	private String studentName;
	private String studentCourse;
	private Double studentMarks;
	private String studentGrade;
	
	//member functions
	public void setData (Integer rollNumber,String studentName,String studentCourse,Double studentMarks,String studentGrade) {
	 this.rollNumber = rollNumber;
	 this.studentName = studentName;
	 this.studentCourse = studentCourse;
	 this.studentMarks = studentMarks;
	}
	public void showData()
	{
		System.out.println("Roll:"+rollNumber);
		System.out.println("Name:"+studentName);
		System.out.println("Course:"+studentCourse);
		System.out.println("Marks:"+studentMarks);
		System.out.println("Grade:"+studentGrade);
		}
	 public void calculateGrade()
	 {
		 if (studentMarks>=90)
			 studentGrade="K";
		 else if (studentMarks>=75)
			 studentGrade="G";
		 else if (studentMarks>=60)
			 studentGrade="P";
		 else 
			 studentGrade ="F";
		 
			 }
}
