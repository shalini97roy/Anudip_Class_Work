package org.anudip.application;

public class MyException extends RuntimeException{

}
