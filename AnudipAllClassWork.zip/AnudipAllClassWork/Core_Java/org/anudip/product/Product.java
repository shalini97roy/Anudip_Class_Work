package org.anudip.product;

public class Product {
	 private Integer productId;
	    private String productName;
	    private Double purchasePrice;
	    private Double salesPrice;

	    public Integer getProductId() {
	        return productId;
	    }

	    public void setProductId(Integer productId) {
	        this.productId = productId;
	    }

	    public String getProductName() {
	        return productName;
	    }

	    public void setProductName(String productName) {
	        this.productName = productName;
	    }

	    public Double getPurchasePrice() {
	        return purchasePrice;
	    }

	    public void setPurchasePrice(Double purchasePrice) {
	        this.purchasePrice = purchasePrice;
	    }

	    public Double getSalesPrice() {
	        return salesPrice;
	    }

	    public void setSalesPrice(Double salesPrice) {
	        this.salesPrice = salesPrice;
	    }

	    @Override
	    public String toString() {
	        return "Product [productId=" + productId + ", productName=" + productName +
	               ", purchasePrice=" + purchasePrice + ", salesPrice=" + salesPrice + "]";
	    }


}
