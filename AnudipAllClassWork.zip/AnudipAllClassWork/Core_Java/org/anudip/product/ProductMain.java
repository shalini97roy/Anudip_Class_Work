package org.anudip.product;

import java.util.Scanner;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);
	        
	        // Accepting product details as input
	        System.out.print("Enter Product ID: ");
	        Integer productId = Integer.parseInt(scanner.nextLine());
	        System.out.print("Enter Product Name: ");
	        String productName = scanner.nextLine();
	        System.out.print("Enter Purchase Price: ");
	        Double purchasePrice = Double.parseDouble(scanner.nextLine());
	        
	        // Creating a Product object
	        Product product = new Product();
	        product.setProductId(productId);
	        product.setProductName(productName);
	        product.setPurchasePrice(purchasePrice);
	        
	        // Calculating the sales price
	        Double salesPrice = purchasePrice + purchasePrice * 0.1;
	        product.setSalesPrice(salesPrice);
	        
	        // Displaying the product details
	        System.out.println(product);
	        
	        scanner.close();
	}
}
