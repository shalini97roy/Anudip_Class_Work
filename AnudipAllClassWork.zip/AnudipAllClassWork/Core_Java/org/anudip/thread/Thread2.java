package org.anudip.thread;
public class Thread2 extends Thread{
	private String word;
	private String rword;
	public Thread2(String word) {
		this.word=word;
		this.rword=null;
	}
	public String show() {
		return rword;
	}
	public void run() {
		try {
			synchronized(this) //t2 requests the system that it will be only active thread, other threads will be inactive
			{
		}
		StringBuilder sb=new StringBuilder(word);
		sb.reverse();
		rword=sb.toString();
		notifyAll();//t2 notifies all the threads that it's task is complete now other threads can be active
	}catch(Exception e){}
}
}