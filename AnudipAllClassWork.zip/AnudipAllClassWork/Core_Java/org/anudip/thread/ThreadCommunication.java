package org.anudip.thread;
public class ThreadCommunication {
	public static void main1(String[] args) {
		// TODO Auto-generated method stub
			Thread1 t1=new Thread1();
			t1.start();
		}//end of void main
	}
