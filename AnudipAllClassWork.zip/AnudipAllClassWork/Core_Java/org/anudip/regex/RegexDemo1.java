package org.anudip.regex;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in); 
		System.out.print("Enter your name: ");
        String input = sc.nextLine();
        String pattern ="(Mr\\.|Mrs\\.|Miss\\.)\\s([A-Za-z]+)";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(input);
        if(matcher.matches()) {
        	String prefix = matcher.group(1);
        	String name = matcher.group(2);
        	System.out.println("Name: "+name);
        	System.out.println("Prefix: "+prefix);
        }
        else {
        	System.out.println("Invalid name format!");
        }

	}

}
