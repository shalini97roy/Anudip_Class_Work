package org.anudip.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a email ID: ");
		String email = scanner.nextLine();
		String pattern = "^[A-Za-z0-9._%+-]+@gmail\\.com$";
		Pattern regex = Pattern.compile(pattern);
		Matcher matcher = regex.matcher(email);
		if(matcher.matches()) {
			System.out.println("This is a Gmail ID.");
			
		}
		else {
			System.out.println("This is not a Gmail ID.");
		}
	}
}
