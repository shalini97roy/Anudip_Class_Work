package org.anudip.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your date of joining: ");
		String date = sc.nextLine();
		 String pattern = "^(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[0-2])-\\d{4}";
		 Pattern regex = Pattern.compile(pattern);
		 Matcher matcher = regex.matcher(date);
			if(matcher.matches()) {
				System.out.println("This is a valid date.");
				
			}
			else {
				System.out.println("This is not a valid date.");
			}

	}

}
