package org.anudip.testing;
import static org.junit.jupiter.api.Assertions.*;

import org.anudip.application.MyMathApp;
import org.junit.jupiter.api.Test;
class MyMathAppTest {

	@Test
	void testAddition() {
		int p=20;
		int q=30;
		int expected=50;
		int actual=new MyMathApp().addition(p,q);
		assertEquals(expected,actual);
	}
/*
	@Test
	void testMultiply() {
		fail("Not yet implemented");
	}

	@Test
	void testDivision() {
		fail("Not yet implemented");
	}*/

}
