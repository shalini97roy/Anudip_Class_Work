package org.anudip.inheritance;
public class InheritMain2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent2 p=new Child2();
		p.show();
	}
}

