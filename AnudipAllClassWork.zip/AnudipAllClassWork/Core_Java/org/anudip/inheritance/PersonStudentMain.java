package org.anudip.inheritance;

public class PersonStudentMain {

		// TODO Auto-generated method stub
		public static void main(String[] args) {
			Student st = new Student();
			st.speak();
			st.study();

	}

}
