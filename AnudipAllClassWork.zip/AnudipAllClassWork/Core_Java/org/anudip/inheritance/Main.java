package org.anudip.inheritance;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Create an object of the Car class
		Car myCar=new Car();
		//Call the "drive" method
		myCar.drive();
		//Call the "honk"method
		myCar.honk();

	}

}
