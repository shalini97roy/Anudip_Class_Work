package org.anudip.inheritance;

public class Car extends Vehicle {
	public String color;
	public void honk()  {
		System.out.println(brand + " " +model+ " (" + year + ")is honking.Honk honk!");
	}

}
