package org.anudip.inheritance;

public class Person {
	public String Name;
	public int age;
	public Person()  {
		Name="Shalini";
		age=25;
	}
	public void speak()  {
		System.out.println("The name of the person: "+Name+"and age is: "+age);
	
	
	

}
}
