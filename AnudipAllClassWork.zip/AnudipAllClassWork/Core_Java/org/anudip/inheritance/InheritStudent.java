package org.anudip.inheritance;

public class InheritStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s = new Student();
		s.speak();
		s.study();

	}

}
