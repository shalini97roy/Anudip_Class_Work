package org.anudip.inheritance;

public class Vehicle {
	public String brand;
	public String model;
	public int year;
	public void drive()   {
		System.out.println(brand + " " +model +"  (" + year + ") is now driving. ");
		
	}

}
