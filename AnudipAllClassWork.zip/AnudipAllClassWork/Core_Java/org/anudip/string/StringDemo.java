package org.anudip.string;

public class StringDemo {

	public static void main(String[] args) {
		String str="ABCDEFGH";
		//convert into char array
		char[] arr=str.toCharArray();
//		for(int i=0;i<arr.length;i++) {
//			System.out.print(arr[i]+" ");
//		}
		for(char element: arr) {
			System.out.print(element+ " ");
		}
	}

}
