package org.anudip.string;
import java.util.Scanner;
public class StringDemo2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        String myName = name.toLowerCase();
        String greeting;
        if (myName.startsWith("mr")) {
            greeting = "Good Afternoon Sir";
        } else if (myName.startsWith("mrs") || myName.startsWith("ms")) {
            greeting = "Good Afternoon Madam";
        } else {
            greeting = "Good Afternoon";
        }

        System.out.println(greeting);
        System.out.println(name);
        scanner.close();	}

}
