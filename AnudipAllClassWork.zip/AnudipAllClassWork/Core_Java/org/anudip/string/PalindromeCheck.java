package org.anudip.string;

import java.util.Scanner;

public class PalindromeCheck {

		public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);      
	        System.out.print("Enter a word: ");
	        String word = scanner.nextLine();

	       
	        StringBuffer stringBuffer = new StringBuffer(word);

	        
	        stringBuffer.reverse();

	        
	        String reversedWord = stringBuffer.toString();

	   
	        if (word.equalsIgnoreCase(reversedWord)) {
	            System.out.println("The word is a palindrome");
	        } else {
	            System.out.println("The word is not a palindrome");
	        }


	}

}
