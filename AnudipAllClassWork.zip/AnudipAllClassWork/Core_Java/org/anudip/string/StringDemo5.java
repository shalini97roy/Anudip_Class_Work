package org.anudip.string;

import java.util.Scanner;

public class StringDemo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str=sc.nextLine();
		System.out.println("Enter the start position: ");
		int n=Integer.parseInt(sc.nextLine());
		n--;
		System.out.println("Enter the number of chars to display: ");
		int m=Integer.parseInt(sc.nextLine());
		m=n+m;
		String sub1=str.substring(n,m);
		System.out.println(sub1);
	}

}
