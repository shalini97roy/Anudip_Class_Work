package org.anudip.string;

import java.util.Scanner;

public class StringDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        System.out.print("Enter the start index: ");
        int startIndex = scanner.nextInt();

        System.out.print("Enter the number of characters to display: ");
        int numChars = scanner.nextInt();

        if (startIndex < 0 || startIndex >= input.length()) {
            System.out.println("Invalid start index!");
            return;
        }

        else if (numChars < 0 || startIndex + numChars > input.length()) {
            System.out.println("Invalid number of characters!");
            return;
        }

        String substring = input.substring(startIndex, startIndex + numChars);
        System.out.println("Result is: " + substring);


	}

}
