package org.anudip.lambda;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*B b = new B();
		b.display();
		b.Present();
		b.show();
		b.putData();*/
		//A a = new B();
//		b.display();
//		b.Present();
		//a.show();
		//a.putData();
		D dd = new DImpl();
		dd.disp();
		dd.show();
	//	dd.putData();


	}

}
