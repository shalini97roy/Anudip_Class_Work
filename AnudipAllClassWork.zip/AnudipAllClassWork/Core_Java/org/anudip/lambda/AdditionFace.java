package org.anudip.lambda;
@FunctionalInterface
public interface AdditionFace {
	
	    public int add(int x,int y);
	}


