package org.anudip.lambda;

import java.util.Scanner;
@FunctionalInterface

public interface CalculatorFace {
	 public int calculate(int x,int y,String op);

}
