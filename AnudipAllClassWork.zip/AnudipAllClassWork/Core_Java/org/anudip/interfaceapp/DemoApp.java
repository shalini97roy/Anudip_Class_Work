package org.anudip.interfaceapp;

public class DemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoFaceImpl df=new DemoFaceImpl();
		df.show();
		df.display();

	}

}
