package org.anudip.interfaceapp;

public interface Shape {
	double pi = 3.1416;

    String perimeter();

    String area();


}
