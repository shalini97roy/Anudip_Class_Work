package org.anudip.interfaceapp;

public class DemoFaceImpl implements DemoFace {

	@Override
	public void show() {
		// TODO Auto-generated method stub
      System.out.println("Hello everybody");
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("HI everybody");

	}

}
