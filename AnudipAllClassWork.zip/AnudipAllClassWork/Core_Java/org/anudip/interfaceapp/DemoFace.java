package org.anudip.interfaceapp;
public interface DemoFace {
	public void show();
	public void display();
	

}
