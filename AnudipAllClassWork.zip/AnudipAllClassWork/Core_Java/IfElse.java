import java.util.Scanner;

public class IfElse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the student's marks percentage: ");
        double percentage = sc.nextDouble();

        String grade;

        if (percentage > 89) {
            grade = "E";
        } else if (percentage > 74) {
            grade = "V";
        } else if (percentage > 59) {
            grade = "G";
        } else if (percentage >= 50) {
            grade = "P";
        } else {
            grade = "F";
        }

        System.out.println("Grade assigned: " + grade);
    }
}
