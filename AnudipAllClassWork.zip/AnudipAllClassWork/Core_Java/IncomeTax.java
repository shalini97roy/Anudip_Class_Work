import java.util.Scanner;

public class IncomeTax {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter employee name: ");
        String employeeName = sc.nextLine();

        System.out.print("Enter annual income: ");
        double annualIncome = sc.nextDouble();

        double incomeTax = calculateIncomeTax(annualIncome);

        System.out.println("\nEmployee Name: " + employeeName);
        System.out.println("Income Tax: " + incomeTax);
    }

    public static double calculateIncomeTax(double annualIncome) {
        if (annualIncome <= 250000) {
            return 0;
        } else if (annualIncome <= 500000) {
            return (annualIncome - 250000) * 0.1;
        } else if (annualIncome <= 1000000) {
            return 30000 + (annualIncome - 500000) * 0.2;
        } else {
            return 50000 + (annualIncome - 1000000) * 0.3;
        }
    }
}

