package fruit;
public class InheritMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derive d = new Derive();
		//d.show();
		d.display();
	}
}
