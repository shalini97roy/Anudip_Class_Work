import java.util.Scanner;

public class PalindromeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a word: ");
        String word = scanner.nextLine();

        boolean isPalindrome = checkPalindrome(word);

        if (isPalindrome) {
            System.out.println(word + " is a palindrome.");
        } else {
            System.out.println(word + " is not a palindrome.");
        }

        scanner.close();
    }

    public static boolean checkPalindrome(String word) {
        String reverse = "";
        int length = word.length();

        for (int i = length - 1; i >= 0; i--) {
            reverse += word.charAt(i);
        }

        return word.equalsIgnoreCase(reverse);
    }
}
