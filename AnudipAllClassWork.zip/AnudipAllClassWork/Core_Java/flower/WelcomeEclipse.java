package flower;

public class WelcomeEclipse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome To Java & Eclipse");
		System.out.println("Hello Everybody Happy UltoRath");

	}

}
