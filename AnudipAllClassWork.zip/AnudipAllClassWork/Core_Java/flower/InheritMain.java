package flower;
public class InheritMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derive2 d = new Derive2();
		//d.show();
		d.display();
	}
}
