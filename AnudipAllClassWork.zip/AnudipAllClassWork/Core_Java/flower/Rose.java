package flower;

public class Rose {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello I am Rose");

	}

	public static void show() {
		// TODO Auto-generated method stub
		
	}

}
