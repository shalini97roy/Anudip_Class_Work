import java.util.Scanner;

public class GreetingApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your name with title (Mr/Mrs/Ms): ");
        String nameWithTitle = scanner.nextLine();

        String name = getNameFromTitle(nameWithTitle);
        String title = getTitleFromName(nameWithTitle);

        if (title.equalsIgnoreCase("Mr")) {
            System.out.println("Good Afternoon Sir, " + name + "!");
        } else if (title.equalsIgnoreCase("Mrs") || title.equalsIgnoreCase("Ms")) {
            System.out.println("Good Afternoon Madam, " + name + "!");
        } else {
            System.out.println("Invalid title provided.");
        }

        scanner.close();
    }

    public static String getNameFromTitle(String nameWithTitle) {
        int titleEndIndex = nameWithTitle.indexOf(' ');
        if (titleEndIndex != -1) {
            return nameWithTitle.substring(titleEndIndex + 1);
        }
        return nameWithTitle;
    }

    public static String getTitleFromName(String nameWithTitle) {
        int titleEndIndex = nameWithTitle.indexOf(' ');
        if (titleEndIndex != -1) {
            return nameWithTitle.substring(0, titleEndIndex);
        }
        return "";
    }
}
